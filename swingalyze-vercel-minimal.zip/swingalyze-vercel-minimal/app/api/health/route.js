export async function GET() {
  return Response.json({ ok: true, service: "swingalyze", time: new Date().toISOString() });
}
