export default function Home() {
  return (
    <main style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', textAlign: 'center', padding: 24 }}>
      <div>
        <h1>✅ Swingalyze is live</h1>
        <p>This is a minimal Next.js app-router skeleton. Deploying this removes the Vercel error.</p>
        <p>Next steps: replace this page with your real app code.</p>
      </div>
    </main>
  );
}
