# Swingalyze (Minimal Vercel-Ready)

This is a minimal, working Next.js (App Router) project intended to immediately fix 404s on Vercel.

## What you get
- Next.js 14 (App Router) with `app/page.js` and `app/layout.js`
- API route at `/api/health` to verify serverless functions
- `vercel.json` forces npm installs on Vercel to avoid Yarn/no-lock issues
- Clean `package.json` scripts for Next

## How to use
1. Upload these files to your GitHub repo root.
2. Delete any `pages/` folder if you intend to use ONLY the App Router.
3. Commit to `main` and let Vercel redeploy.
4. Visit `/` and `/api/health` — both should work.
