# Swingalyze (Minimal Next.js 14 Skeleton)

This is a minimal app-router project so Vercel builds successfully.
