"use client";

import { useState } from "react";

export default function Home() {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState("");

  async function ping() {
    const res = await fetch("/api/health");
    const data = await res.json();
    alert("API health: " + JSON.stringify(data));
  }

  return (
    <main>
      <h1 style={{ fontSize: 32, marginBottom: 8 }}>Swingalyze</h1>
      <p style={{ color: "#555", marginBottom: 24 }}>
        Deployed and working. Upload is a placeholder; API health route proves the server is live.
      </p>

      <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
        <button onClick={ping} style={{ padding: "10px 14px", border: "1px solid #ddd", borderRadius: 8, cursor: "pointer" }}>Check API Health</button>
        <a href="https://swingalyze.vercel.app" target="_blank" style={{ padding: "10px 14px", border: "1px solid #ddd", borderRadius: 8, textDecoration: "none" }}>Open Deployed Site</a>
      </div>

      <label style={{ display: "block", marginBottom: 8, fontWeight: 600 }}>Upload a swing (demo only)</label>
      <input type="file" accept="image/*,video/*" onChange={(e) => setFile(e.target.files?.[0] ?? null)} />
      <div style={{ marginTop: 12 }}>
        <button
          onClick={() => setStatus(file ? `Received: ${file.name}` : "Choose a file first")}
          style={{ padding: "10px 14px", border: "1px solid #ddd", borderRadius: 8, cursor: "pointer" }}
        >
          Analyze (placeholder)
        </button>
        <div style={{ marginTop: 8, color: "#333" }}>{status}</div>
      </div>
    </main>
  );
}
