# Swingalyze (Next.js App Router Starter)

A minimal, deploy-ready Next.js (TypeScript) starter for Swingalyze.

## Quick Start
1) **Install**: `npm i`
2) **Run dev**: `npm run dev` (opens http://localhost:3000)
3) **Build**: `npm run build` then `npm start`

## Deploy on Vercel
Connect this GitHub repo in Vercel. Framework is auto-detected.

## Project Structure
```
src/app/page.tsx        # Home page
src/app/api/health/route.ts # Simple health endpoint
public/assets/           # Static files
```

## Environment
Duplicate `.env.example` as `.env.local` if needed.
