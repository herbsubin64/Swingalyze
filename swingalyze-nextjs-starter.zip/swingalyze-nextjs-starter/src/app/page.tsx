import Link from "next/link";
import Image from "next/image";

export default function HomePage() {
  return (
    <main style={{maxWidth: 920, margin: "40px auto", padding: "0 16px"}}>
      <header style={{display: "flex", alignItems: "center", gap: 12}}>
        <Image src="/assets/logo.svg" alt="Swingalyze" width={40} height={40} />
        <h1 style={{margin: 0}}>Swingalyze</h1>
      </header>

      <p style={{marginTop: 12}}>
        Next.js starter is installed and ready. Upload to GitHub and deploy to Vercel.
      </p>

      <section style={{marginTop: 24, padding: 16, border: "1px solid #eee", borderRadius: 8}}>
        <h2 style={{marginTop: 0}}>Quick Test</h2>
        <p>
          Try the <code>/api/health</code> endpoint to confirm the server is running.
        </p>
        <p>
          <Link href="/api/health">Open health check</Link>
        </p>
      </section>

      <section style={{marginTop: 24, padding: 16, border: "1px solid #eee", borderRadius: 8}}>
        <h2 style={{marginTop: 0}}>Upload Demo (client only)</h2>
        <p>Choose a file to verify basic client-side behavior.</p>
        <input type="file" onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) alert(`Selected: ${file.name} (${file.size} bytes)`);
        }} />
      </section>

      <footer style={{marginTop: 48, opacity: 0.7}}>
        <small>© {new Date().getFullYear()} Swingalyze</small>
      </footer>
    </main>
  );
}
